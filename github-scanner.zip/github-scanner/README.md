# Strict Crypto Futures Scanner (GitHub Actions)

Scanner otomatis **Strict Quality** yang jalan setiap 1 jam di GitHub Actions, lalu mengirim sinyal **Valid (≥75%)** dan **SNIPER (≥82%)** ke Discord.

Tidak perlu buka browser / HP.

---

## Cara Setup (5–10 menit)

### 1. Buat Repository GitHub
1. Login ke [github.com](https://github.com)
2. Klik **New repository**
3. Nama bebas (contoh: `crypto-strict-scanner`)
4. Public atau Private → **Create repository**

### 2. Upload File
Upload 3 file ini ke repository:
- `scanner.js`
- `package.json`
- `.github/workflows/scan.yml`  ← **folder `.github/workflows` harus ada**

Cara termudah:
- Klik **Add file → Upload files**
- Drag semua file (termasuk folder `.github`)
- Commit

Atau pakai Git di komputer:
```bash
git clone https://github.com/USERNAME/crypto-strict-scanner.git
cd crypto-strict-scanner
# copy file-file ke folder ini
git add .
git commit -m "Add strict scanner"
git push
```

### 3. Pasang Discord Webhook (Secret)
1. Di repository → **Settings** → **Secrets and variables** → **Actions**
2. Klik **New repository secret**
3. Name: `DISCORD_WEBHOOK`
4. Value: paste webhook Discord kamu  
   `https://discord.com/api/webhooks/1546102132548173944/8zuSoP5UUZ0ABuG3DTM6B5idZF1WEDEiMLw9meEnPA7IvApxw0BNsC_iU40_LT538uiC`
5. **Add secret**

### 4. Aktifkan Actions
1. Tab **Actions** di repository
2. Jika diminta, klik **I understand my workflows, go ahead and enable them**
3. Pilih workflow **Strict Crypto Scanner**
4. Klik **Run workflow** (untuk test manual pertama kali)

### 5. Selesai
- Otomatis jalan **setiap 1 jam**
- Hanya kirim sinyal berkualitas tinggi ke Discord
- Bisa dijalankan manual kapan saja dari tab Actions → Run workflow

---

## Jadwal
Default: setiap jam (`0 * * * *` UTC).

Mau lebih sering (misal tiap 30 menit)? Ubah di file `.github/workflows/scan.yml`:
```yaml
- cron: "*/30 * * * *"
```

---

## Catatan
- Free tier GitHub Actions cukup untuk jadwal per jam.
- Risk management tetap tanggung jawab kamu (max 0.75% disarankan).
- Manual validation tetap diperlukan.
